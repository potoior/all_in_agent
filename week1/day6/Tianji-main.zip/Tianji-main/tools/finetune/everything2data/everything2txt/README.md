1.python版本为3.9
2.使用前请运行以下命令 pip install -r requirements.txt去安装对应的包
3.执行脚本前先确定文件目录input_directory和output_directory的位置，并将文件导入到input_directory目录中
4.之后使用 py .\\everything_to_txt.py执行脚本
