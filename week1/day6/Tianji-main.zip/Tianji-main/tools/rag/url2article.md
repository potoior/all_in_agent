只需在任何 URL 前添加 https://r.jina.ai/。例如，要将 URL https://en.wikipedia.org/wiki/Artificial_intelligence 转换为 LLM 友好的输入，请使用以下 URL：

https://r.jina.ai/https://en.wikipedia.org/wiki/Artificial_intelligence

更多信息请访问：https://github.com/jina-ai/reader
