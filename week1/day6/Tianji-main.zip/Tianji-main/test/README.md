# 测试文件

此目录用于存放各功能测试脚本,包括各模型调用示例与模块调用实现.

## agnets

用于存放 agent 相关测试脚本

## knowledges

用于存放RAG模块相关测试使用脚本

## llm

用于存放 local 以及 cloud llm 的调用参数和调用示例.

## 场景分类

场景分类用于指导语料的查找方向，提供prompt编写的参考方向和最后做finetune语料的查找方向，并帮助扩充prompt的泛化性。

## Prompt部分

Prompt部分包含了团队成员贡献的初步prompt，供大家参考和使用。
