# 贡献者记录

感谢每一位小伙伴对该项目的贡献！您在提交PR的时候可以顺带修改这个文件记录（如果想的话），非常感谢，让我们携手见证真正AGI的来临。（如果喜欢，您也可以把这里当作一个提交PR后的寄语墙）

| 姓名             | 主页                  | 个人贡献                        | 想说的话                            |
|----------------|-------------------------------------------|-----------------------------|---------------------------------|
| sanbuphy       | https://github.com/sanbuphy               | 组织 & 持续推动项目全环节                   | 希望能帮大家留出更多时间探索真我。               |
| Shiqi Ding     | https://github.com/GoldWaterFall          | 数据采集 & Prompt管理             | 希望能慢慢搭建出prompt治理和数据集治理的体系       |
| jujimeizuo     | https://github.com/jujimeizuo             | 参与 Agent 实现                 | 和志同道合的朋友做热爱的事情                  |
| aJupyter       | https://github.com/aJupyter               | 模型微调、训练           | 想到就去做                           |
| LiJianan_SJTU  | https://github.com/OpenMMLab-Assistant005 | prompt工程师（haha）、王牌美工        |                                 |
| MING_X         | https://github.com/MING-ZCH               | Human-like表达，人类情感对齐，心理领域知识库 | 探索情感智能的未来~                      |
| Jiaojiao Li    | https://github.com/Aphasia0515            | 参与构建prompt                  |                                 |
| wuyingxue1230  | https://github.com/wuyingxue1230          | 官网+AI游戏界面设计                 |                                 |
| hl123-123      | https://github.com/hl123-123              | tianji框架整理                  |                                 |
| ElsaWang1215   | https://github.com/ElsaWang1215           | prompt工程  项目文档撰写                  |好奇大模型在人情世故领域能走多远！                                 |
| Yitong Guo     | https://github.com/Dobbytheelfisfree      | 参与构建prompt                  |                                 |
| AmyWu          | https://github.com/AmyWu-CN               | AI游戏prompt、语料收集             | 勇敢做自己！                          |
| Neo            | https://github.com/neowalter              | fake paper                  |                                 |
| JoyWang99      | https://github.com/JOY-Swang              | todo: 模型微调v2.0              |                                 |
| Logan Zou      | https://github.com/logan-zou              | 参与知识库构建                     |                                 |
| Yixue          | https://github.com/yxyibb                 | 场景及场景prompt构建管理、微调数据构建      | 回归开源最本身的纯粹                      |
| xiaoliang wang | https://github.com/tomowang               | 初版官网结构及样式                   |                                 |
| LXY            | https://github.com/xinyulin0807           | 网站调整                        | 感谢大佬们愿意带我这个萌新                   |
| 不要葱姜蒜          | https://github.com/KMnO4-zx               | 模型微调、训练                     | For the Dreamer，For the Leaner！ |
| dingyue772     | https://github.com/dingyue772             | 参与构建prompt                  |
|jianfeng777 |   https://github.com/jianfeng777 |  参与gradio前端制作 |  希望开源社区越来越繁荣！|  
|DISKETR         |   https://github.com/DISKETR |  lora微调   |  Generative Intelligence, Endless Creativity |  
|      |          |                   |
