# 部署到 OpenXLab

## 祝福模块

- 祝福模块部署地址：https://openxlab.org.cn/apps/detail/tackhwa00/Tianji-Wishes

- 敬酒模块部署地址：https://openxlab.org.cn/apps/detail/tackhwa00/Tianji-Etiquette